package ${packageName}.presenter;
import library.base.BasePresenter;
/**
 * ${customName} P
 */
public class ${customName}Presenter extends BasePresenter<${customName}Contract.View> implements ${customName}Contract.Presenter {
    public ${customName}Presenter(${customName}Contract.View view) {
        super(view);
    }
}
